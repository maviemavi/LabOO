void menu();

int main (){
    void menu();

    return 0;
}